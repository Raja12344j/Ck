// save as server.js
// npm install express ws axios fca-mafiya uuid

<TRUNCATED>